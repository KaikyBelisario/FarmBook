package com.example.farmbook;

import android.view.LayoutInflater;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.database.core.view.View;

import java.util.List;

public class Farm {

    public String fnome, fcriador, flink;

    public String getFnome() {
        return fnome;
    }

    public String getFcriador() {
        return fcriador;
    }

    public String getFlink() {
        return flink;
    }
}
