package com.example.farmbook;

public class Usuario {
    public String email, nome;
    public Usuario(String email, String nome) {
        this.email = email;
        this.nome = nome;
    }
}
