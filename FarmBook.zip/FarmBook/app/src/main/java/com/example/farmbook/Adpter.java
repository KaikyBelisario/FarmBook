package com.example.farmbook;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.lang.reflect.Array;
import java.util.ArrayList;

public class Adpter extends RecyclerView.Adapter<Adpter.Viewholder> {

    Context context;

    ArrayList<Farm> list;

    public Adpter(Context context, ArrayList<Farm> list) {
        this.context = context;
        this.list = list;
    }

    @NonNull
    @Override
    public Viewholder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(context).inflate(R.layout.item,parent,false);
        return new Viewholder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull Viewholder holder, int position) {

        Farm farm = list.get(position);
        holder.fnome.setText(farm.getFcriador());
        holder.fcriador.setText(farm.getFcriador());

    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    public static class Viewholder extends RecyclerView.ViewHolder {

        TextView fnome, fcriador;

        public Viewholder(@NonNull View itemView) {
            super(itemView);

            fnome = itemView.findViewById(R.id.fnome);
            fcriador = itemView.findViewById(R.id.fcriador);

        }
    }
}
